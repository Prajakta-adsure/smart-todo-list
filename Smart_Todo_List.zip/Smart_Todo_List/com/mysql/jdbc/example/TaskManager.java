package com.mysql.jdbc.example;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.Text;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

public class TaskManager {
    private ObservableList<Task> tasks;
    private VBox taskListUI;
    private TextField searchField;

    // Database configuration constants
    private static final String DB_URL = "jdbc:mysql://localhost:3306/Todo_List";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "Anita@16";

    public TaskManager() {
        tasks = FXCollections.observableArrayList();
        taskListUI = new VBox(10);
        taskListUI.setPadding(new Insets(10));

        // Initialize searchField to avoid null issues
        searchField = new TextField();
        searchField.setPromptText("Search tasks...");

        loadTasksFromDatabase();
        renderTaskList(); // Ensure searchField is not null before calling this method
    }

    public VBox getUI() {
        VBox mainContainer = new VBox(10);
        mainContainer.setPadding(new Insets(10));

        // Input fields
        TextField titleInput = new TextField();
        titleInput.setPromptText("Task Title");

        TextArea descriptionInput = new TextArea();
        descriptionInput.setPromptText("Task Description");

        DatePicker deadlinePicker = new DatePicker();

        ComboBox<String> prioritySelector = new ComboBox<>();
        prioritySelector.setItems(FXCollections.observableArrayList("Urgent", "Important", "Low Priority"));
        prioritySelector.setPromptText("Select Priority");

        // Add Task button
        Button addButton = new Button("Add Task");
        addButton.setOnAction(e -> {
            String title = titleInput.getText();
            String description = descriptionInput.getText();
            LocalDate deadline = deadlinePicker.getValue();
            String priority = prioritySelector.getValue();

            if (title.isEmpty() || deadline == null || priority == null) {
                showAlert("Please fill in all fields");
                return;
            }

            Task newTask = new Task(title, description, deadline.toString(), priority);
            tasks.add(newTask);
            saveTaskToDatabase(newTask);

            titleInput.clear();
            descriptionInput.clear();
            deadlinePicker.setValue(null);
            prioritySelector.setValue(null);

            renderTaskList();
        });

        // Attach a listener to searchField for filtering tasks dynamically
        searchField.textProperty().addListener((observable, oldValue, newValue) -> renderTaskList());

        HBox inputBox = new HBox(10, titleInput, descriptionInput, deadlinePicker, prioritySelector, addButton);
        inputBox.setPadding(new Insets(10));
        inputBox.setSpacing(10);

        mainContainer.getChildren().addAll(searchField, inputBox, taskListUI);

        return mainContainer;
    }

    private void renderTaskList() {
        taskListUI.getChildren().clear();

        String searchQuery = searchField.getText() == null ? "" : searchField.getText().toLowerCase();

        // Filter tasks based on the search query
        tasks.stream()
                .filter(task -> task.getTitle().toLowerCase().contains(searchQuery) ||
                        task.getDescription().toLowerCase().contains(searchQuery) ||
                        task.getPriority().toLowerCase().contains(searchQuery))
                .sorted((t1, t2) -> t1.getDeadline().compareTo(t2.getDeadline()))
                .forEach(task -> {
                    VBox taskItem = new VBox(5);
                    taskItem.setPadding(new Insets(5));
                    taskItem.setStyle("-fx-border-color: lightgray; -fx-padding: 5; -fx-background-color: #f9f9f9;");

                    Text taskDetails = new Text(task.toString());
                    Text descriptionDetails = new Text("Description: " + task.getDescription());

                    Button deleteButton = new Button("Delete");
                    deleteButton.setOnAction(e -> {
                        tasks.remove(task);
                        deleteTaskFromDatabase(task.getId());
                        renderTaskList();
                    });

                    taskItem.getChildren().addAll(taskDetails, descriptionDetails, deleteButton);
                    taskListUI.getChildren().add(taskItem);
                });
    }

    private void loadTasksFromDatabase() {
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String query = "SELECT * FROM tasks";
            PreparedStatement stmt = conn.prepareStatement(query);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Task task = new Task(
                        rs.getInt("id"),
                        rs.getString("title"),
                        rs.getString("description"),
                        rs.getString("deadline"),
                        rs.getString("priority")
                );
                tasks.add(task);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void saveTaskToDatabase(Task task) {
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String query = "INSERT INTO tasks (title, description, deadline, priority) VALUES (?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, task.getTitle());
            stmt.setString(2, task.getDescription());
            stmt.setString(3, task.getDeadline());
            stmt.setString(4, task.getPriority());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void deleteTaskFromDatabase(int taskId) {
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String query = "DELETE FROM tasks WHERE id = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, taskId);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void showAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setContentText(message);
        alert.show();
    }
}
