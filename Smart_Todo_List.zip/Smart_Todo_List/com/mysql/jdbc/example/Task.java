package com.mysql.jdbc.example;
public class Task {
    private int id;
    private String title;
    private String description;
    private String deadline;
    private String priority;

    public Task(String title, String description, String deadline, String priority) {
        this(-1, title, description, deadline, priority);
    }

    public Task(int id, String title, String description, String deadline, String priority) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.deadline = deadline;
        this.priority = priority;
    }

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public String getDeadline() {
        return deadline;
    }

    public String getPriority() {
        return priority;
    }

    @Override
    public String toString() {
        return "[" + priority + "] " + title + " - Due: " + deadline;
    }
}
